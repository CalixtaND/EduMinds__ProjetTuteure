import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const COLORS = {
  violet: '#6D597A',
  violetDeep: '#5A4866',
  celadonDeep: '#7A9E6A',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
};

export default function ChallengeLiveScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()} activeOpacity={0.75}>
          <Ionicons name="chevron-back" size={20} color={COLORS.ink} />
        </TouchableOpacity>
        <View style={styles.topLine}>
          <Text style={styles.kicker}>Question 3 sur 5</Text>
          <Text style={styles.timer}>00:12</Text>
        </View>
        <Text style={styles.title}>Challenge live</Text>

        <View style={styles.questionCard}>
          <Text style={styles.question}>Quelle structure evite les anomalies de mise a jour en SQL ?</Text>
          <View style={styles.choiceGood}>
            <Text style={styles.choiceText}>La normalisation</Text>
          </View>
          <View style={styles.choice}>
            <Text style={styles.choiceMuted}>La duplication controlee</Text>
          </View>
          <View style={styles.choice}>
            <Text style={styles.choiceMuted}>Le tri alphabetique</Text>
          </View>
        </View>

        <View style={styles.scoreboard}>
          <Text style={styles.scoreTitle}>Classement en direct</Text>
          <Text style={styles.scoreLine}>1. Mireille · 840 pts</Text>
          <Text style={styles.scoreLine}>2. Laure · 790 pts</Text>
          <Text style={styles.scoreLine}>3. Kevin · 650 pts</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.parchment },
  content: { padding: 20, paddingBottom: 34 },
  backButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 16,
    borderWidth: 1,
    height: 42,
    justifyContent: 'center',
    marginBottom: 18,
    width: 42,
  },
  topLine: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  timer: {
    backgroundColor: COLORS.violetDeep,
    borderRadius: 999,
    color: COLORS.white,
    fontSize: 13,
    fontWeight: '900',
    overflow: 'hidden',
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  title: {
    color: COLORS.ink,
    fontSize: 31,
    fontWeight: '900',
    letterSpacing: 0,
    marginTop: 4,
  },
  questionCard: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 24,
    borderWidth: 1,
    marginTop: 22,
    padding: 18,
  },
  question: {
    color: COLORS.ink,
    fontSize: 23,
    fontWeight: '900',
    lineHeight: 31,
  },
  choiceGood: {
    backgroundColor: '#EDF2EA',
    borderColor: '#D3E0CC',
    borderRadius: 16,
    borderWidth: 1,
    marginTop: 18,
    padding: 15,
  },
  choice: {
    backgroundColor: '#F5F3ED',
    borderRadius: 16,
    marginTop: 10,
    padding: 15,
  },
  choiceText: {
    color: COLORS.celadonDeep,
    fontSize: 15,
    fontWeight: '900',
  },
  choiceMuted: {
    color: COLORS.inkSoft,
    fontSize: 15,
    fontWeight: '800',
  },
  scoreboard: {
    backgroundColor: COLORS.violetDeep,
    borderRadius: 22,
    marginTop: 16,
    padding: 16,
  },
  scoreTitle: {
    color: COLORS.white,
    fontSize: 17,
    fontWeight: '900',
    marginBottom: 10,
  },
  scoreLine: {
    color: '#F5F1F7',
    fontSize: 14,
    fontWeight: '800',
    marginTop: 7,
  },
});
