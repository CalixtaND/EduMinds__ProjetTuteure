import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const COLORS = {
  violet: '#6D597A',
  celadonDeep: '#7A9E6A',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
  warning: '#FFF5E8',
};

const criteria = ['Temps de reponse', 'Difficulte question', 'Confiance declaree', 'Historique'];

export default function DiagnosticScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()} activeOpacity={0.75}>
          <Ionicons name="chevron-back" size={20} color={COLORS.ink} />
        </TouchableOpacity>

        <Text style={styles.kicker}>Niveau et filiere</Text>
        <Text style={styles.title}>Diagnostic</Text>
        <Text style={styles.subtitle}>
          Cette evaluation calibre le planning selon ton niveau reel, pas seulement ta classe.
        </Text>

        <View style={styles.warningCard}>
          <Ionicons name="lock-closed-outline" size={22} color="#8A5A20" />
          <Text style={styles.warningText}>
            Pendant le diagnostic, quitter l'application annule la tentative en cours.
          </Text>
        </View>

        <View style={styles.questionCard}>
          <View style={styles.progressHeader}>
            <Text style={styles.progressText}>Question 1 sur 8</Text>
            <Text style={styles.timer}>00:38</Text>
          </View>
          <Text style={styles.question}>
            Dans une base relationnelle, pourquoi separe-t-on les tables par entites ?
          </Text>
          <View style={styles.choice}>
            <Text style={styles.choiceText}>Pour reduire les duplications et garantir la coherence.</Text>
          </View>
          <View style={styles.choiceMuted}>
            <Text style={styles.choiceMutedText}>Pour accelerer uniquement l'affichage des pages.</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Score calcule avec</Text>
        {criteria.map((item) => (
          <View key={item} style={styles.criteriaRow}>
            <Ionicons name="analytics-outline" size={18} color={COLORS.violet} />
            <Text style={styles.criteriaText}>{item}</Text>
          </View>
        ))}

        <TouchableOpacity style={styles.primaryButton} activeOpacity={0.85}>
          <Text style={styles.primaryButtonText}>Commencer l'evaluation</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.parchment },
  content: { padding: 20, paddingBottom: 34 },
  backButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 16,
    borderWidth: 1,
    height: 42,
    justifyContent: 'center',
    marginBottom: 18,
    width: 42,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 31,
    fontWeight: '900',
    letterSpacing: 0,
    marginTop: 4,
  },
  subtitle: {
    color: COLORS.inkSoft,
    fontSize: 15,
    fontWeight: '600',
    lineHeight: 22,
    marginTop: 10,
  },
  warningCard: {
    alignItems: 'center',
    backgroundColor: COLORS.warning,
    borderColor: '#E8B870',
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 12,
    marginTop: 22,
    padding: 16,
  },
  warningText: {
    color: '#8A5A20',
    flex: 1,
    fontSize: 14,
    fontWeight: '800',
    lineHeight: 20,
  },
  questionCard: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 24,
    borderWidth: 1,
    marginTop: 18,
    padding: 18,
  },
  progressHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 18,
  },
  progressText: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '900',
  },
  timer: {
    backgroundColor: '#EDE8F0',
    borderRadius: 999,
    color: COLORS.violet,
    fontSize: 12,
    fontWeight: '900',
    overflow: 'hidden',
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  question: {
    color: COLORS.ink,
    fontSize: 22,
    fontWeight: '900',
    lineHeight: 30,
  },
  choice: {
    backgroundColor: '#EDF2EA',
    borderColor: '#D3E0CC',
    borderRadius: 16,
    borderWidth: 1,
    marginTop: 18,
    padding: 14,
  },
  choiceText: {
    color: COLORS.celadonDeep,
    fontSize: 14,
    fontWeight: '800',
    lineHeight: 20,
  },
  choiceMuted: {
    backgroundColor: '#F5F3ED',
    borderRadius: 16,
    marginTop: 10,
    padding: 14,
  },
  choiceMutedText: {
    color: COLORS.muted,
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 20,
  },
  sectionTitle: {
    color: COLORS.ink,
    fontSize: 18,
    fontWeight: '900',
    marginBottom: 10,
    marginTop: 22,
  },
  criteriaRow: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 16,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 10,
    marginBottom: 9,
    padding: 13,
  },
  criteriaText: {
    color: COLORS.inkSoft,
    fontSize: 14,
    fontWeight: '800',
  },
  primaryButton: {
    alignItems: 'center',
    backgroundColor: COLORS.violet,
    borderRadius: 18,
    marginTop: 12,
    paddingVertical: 16,
  },
  primaryButtonText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '900',
  },
});
