import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const COLORS = {
  violet: '#6D597A',
  blue: '#6E8894',
  blueSoft: '#EDF2F4',
  celadonDeep: '#7A9E6A',
  celadonSoft: '#EDF2EA',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
};

const generatedCards = [
  'Difference entre liaison ionique et covalente',
  'Role de l ATP dans le metabolisme',
  'Etapes principales de la glycolyse',
];

export function ImportCourseContent({ showBack = true }: { showBack?: boolean }) {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {showBack ? (
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()} activeOpacity={0.75}>
            <Ionicons name="chevron-back" size={20} color={COLORS.ink} />
          </TouchableOpacity>
        ) : (
          <View style={styles.topSpacer} />
        )}

        <Text style={styles.kicker}>Generation IA</Text>
        <Text style={styles.title}>Importer un cours</Text>
        <Text style={styles.subtitle}>
          Ajoute une photo ou un PDF. Synapz extrait les notions importantes et prepare tes
          flashcards pour le mode hors-ligne.
        </Text>

        <View style={styles.dropZone}>
          <View style={styles.dropIcon}>
            <Ionicons name="document-attach-outline" size={34} color={COLORS.white} />
          </View>
          <Text style={styles.dropTitle}>Selectionner un fichier</Text>
          <Text style={styles.dropText}>PDF, photo du tableau ou notes scannees</Text>
        </View>

        <View style={styles.optionsRow}>
          <TouchableOpacity style={styles.optionButton} activeOpacity={0.8}>
            <Ionicons name="camera-outline" size={22} color={COLORS.violet} />
            <Text style={styles.optionText}>Photo</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.optionButton} activeOpacity={0.8}>
            <Ionicons name="folder-open-outline" size={22} color={COLORS.violet} />
            <Text style={styles.optionText}>PDF</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.previewCard}>
          <View style={styles.previewHeader}>
            <Text style={styles.sectionTitle}>Apercu des flashcards</Text>
            <Text style={styles.badge}>3 cartes</Text>
          </View>
          {generatedCards.map((card) => (
            <View key={card} style={styles.generatedRow}>
              <Ionicons name="sparkles-outline" size={18} color={COLORS.celadonDeep} />
              <Text style={styles.generatedText}>{card}</Text>
            </View>
          ))}
        </View>

        <TouchableOpacity style={styles.primaryButton} activeOpacity={0.85}>
          <Ionicons name="flash-outline" size={18} color={COLORS.white} />
          <Text style={styles.primaryButtonText}>Generer les flashcards</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

export default function ImportCourseScreen() {
  return <ImportCourseContent />;
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.parchment,
  },
  topSpacer: {
    height: 8,
  },
  content: {
    padding: 20,
    paddingBottom: 34,
  },
  backButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 16,
    borderWidth: 1,
    height: 42,
    justifyContent: 'center',
    marginBottom: 18,
    width: 42,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 31,
    fontWeight: '900',
    letterSpacing: 0,
    marginTop: 4,
  },
  subtitle: {
    color: COLORS.inkSoft,
    fontSize: 15,
    fontWeight: '600',
    lineHeight: 22,
    marginTop: 10,
  },
  dropZone: {
    alignItems: 'center',
    backgroundColor: COLORS.blueSoft,
    borderColor: '#CAD7DD',
    borderRadius: 24,
    borderStyle: 'dashed',
    borderWidth: 2,
    marginTop: 24,
    padding: 28,
  },
  dropIcon: {
    alignItems: 'center',
    backgroundColor: COLORS.blue,
    borderRadius: 24,
    height: 62,
    justifyContent: 'center',
    width: 62,
  },
  dropTitle: {
    color: COLORS.ink,
    fontSize: 19,
    fontWeight: '900',
    marginTop: 16,
  },
  dropText: {
    color: COLORS.muted,
    fontSize: 13,
    fontWeight: '700',
    marginTop: 4,
    textAlign: 'center',
  },
  optionsRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 14,
  },
  optionButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flex: 1,
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'center',
    paddingVertical: 15,
  },
  optionText: {
    color: COLORS.violet,
    fontSize: 14,
    fontWeight: '900',
  },
  previewCard: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 22,
    borderWidth: 1,
    marginTop: 22,
    padding: 16,
  },
  previewHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionTitle: {
    color: COLORS.ink,
    fontSize: 17,
    fontWeight: '900',
  },
  badge: {
    backgroundColor: COLORS.celadonSoft,
    borderRadius: 999,
    color: COLORS.celadonDeep,
    fontSize: 12,
    fontWeight: '900',
    overflow: 'hidden',
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  generatedRow: {
    alignItems: 'center',
    borderTopColor: '#F0EEE7',
    borderTopWidth: 1,
    flexDirection: 'row',
    gap: 10,
    paddingVertical: 12,
  },
  generatedText: {
    color: COLORS.inkSoft,
    flex: 1,
    fontSize: 14,
    fontWeight: '700',
  },
  primaryButton: {
    alignItems: 'center',
    backgroundColor: COLORS.violet,
    borderRadius: 18,
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'center',
    marginTop: 18,
    paddingVertical: 16,
  },
  primaryButtonText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '900',
  },
});
