import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const COLORS = {
  violet: '#6D597A',
  blue: '#6E8894',
  celadonDeep: '#7A9E6A',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
};

const chapters = [
  { title: 'Enzymes et catalyse', progress: 86 },
  { title: 'Glycolyse', progress: 68 },
  { title: 'Cycle de Krebs', progress: 42 },
];

export default function SubjectDetailScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()} activeOpacity={0.75}>
          <Ionicons name="chevron-back" size={20} color={COLORS.ink} />
        </TouchableOpacity>
        <Text style={styles.kicker}>Detail matiere</Text>
        <Text style={styles.title}>Biochimie</Text>
        <Text style={styles.subtitle}>78% de maitrise · 12 cartes dues · examen dans 6 jours</Text>

        <View style={styles.masteryCard}>
          <Text style={styles.masteryNumber}>78%</Text>
          <Text style={styles.masteryText}>Maitrise estimee par repetitions, temps de reponse et difficulte.</Text>
        </View>

        <Text style={styles.sectionTitle}>Chapitres</Text>
        {chapters.map((chapter) => (
          <View key={chapter.title} style={styles.chapterCard}>
            <View style={styles.chapterTop}>
              <Text style={styles.chapterTitle}>{chapter.title}</Text>
              <Text style={styles.chapterPercent}>{chapter.progress}%</Text>
            </View>
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, { width: `${chapter.progress}%` }]} />
            </View>
          </View>
        ))}

        <TouchableOpacity style={styles.primaryButton} activeOpacity={0.85}>
          <Ionicons name="albums" size={17} color={COLORS.white} />
          <Text style={styles.primaryButtonText}>Reviser cette matiere</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.parchment },
  content: { padding: 20, paddingBottom: 34 },
  backButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 16,
    borderWidth: 1,
    height: 42,
    justifyContent: 'center',
    marginBottom: 18,
    width: 42,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 31,
    fontWeight: '900',
    letterSpacing: 0,
    marginTop: 4,
  },
  subtitle: {
    color: COLORS.inkSoft,
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 22,
    marginTop: 8,
  },
  masteryCard: {
    backgroundColor: COLORS.violet,
    borderRadius: 24,
    marginTop: 22,
    padding: 20,
  },
  masteryNumber: {
    color: COLORS.white,
    fontSize: 42,
    fontWeight: '900',
  },
  masteryText: {
    color: '#F5F1F7',
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 20,
    marginTop: 4,
  },
  sectionTitle: {
    color: COLORS.ink,
    fontSize: 18,
    fontWeight: '900',
    marginBottom: 10,
    marginTop: 22,
  },
  chapterCard: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    marginBottom: 10,
    padding: 15,
  },
  chapterTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  chapterTitle: {
    color: COLORS.ink,
    fontSize: 15,
    fontWeight: '900',
  },
  chapterPercent: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '900',
  },
  progressTrack: {
    backgroundColor: '#EFEEE8',
    borderRadius: 999,
    height: 8,
    overflow: 'hidden',
  },
  progressFill: {
    backgroundColor: COLORS.celadonDeep,
    borderRadius: 999,
    height: '100%',
  },
  primaryButton: {
    alignItems: 'center',
    backgroundColor: COLORS.violet,
    borderRadius: 18,
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'center',
    marginTop: 10,
    paddingVertical: 16,
  },
  primaryButtonText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '900',
  },
});
