import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const COLORS = {
  violet: '#6D597A',
  celadonDeep: '#7A9E6A',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
  warning: '#FFF5E8',
};

export default function SessionResultsScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()} activeOpacity={0.75}>
          <Ionicons name="chevron-back" size={20} color={COLORS.ink} />
        </TouchableOpacity>
        <Text style={styles.kicker}>Fin de session</Text>
        <Text style={styles.title}>Resultats</Text>

        <View style={styles.scoreCard}>
          <Text style={styles.score}>82%</Text>
          <Text style={styles.scoreLabel}>Maitrise moyenne</Text>
          <Text style={styles.scoreText}>18 cartes revues · 5 cartes reviennent demain · 9 cartes avancees.</Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.rowLabel}>Temps moyen</Text>
          <Text style={styles.rowValue}>12.4s</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Difficulte detectee</Text>
          <Text style={styles.rowValue}>Moyenne</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Prochaine revision</Text>
          <Text style={styles.rowValue}>Demain</Text>
        </View>

        <View style={styles.assistantCard}>
          <Ionicons name="sparkles-outline" size={22} color={COLORS.celadonDeep} />
          <Text style={styles.assistantText}>
            Synapz a raccourci les intervalles sur le cycle de Krebs, car tes reponses etaient lentes.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.parchment },
  content: { padding: 20, paddingBottom: 34 },
  backButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 16,
    borderWidth: 1,
    height: 42,
    justifyContent: 'center',
    marginBottom: 18,
    width: 42,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 31,
    fontWeight: '900',
    letterSpacing: 0,
    marginTop: 4,
  },
  scoreCard: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 24,
    borderWidth: 1,
    marginTop: 22,
    padding: 22,
  },
  score: {
    color: COLORS.celadonDeep,
    fontSize: 52,
    fontWeight: '900',
  },
  scoreLabel: {
    color: COLORS.ink,
    fontSize: 18,
    fontWeight: '900',
  },
  scoreText: {
    color: COLORS.muted,
    fontSize: 13,
    fontWeight: '700',
    lineHeight: 19,
    marginTop: 8,
    textAlign: 'center',
  },
  row: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
    padding: 15,
  },
  rowLabel: {
    color: COLORS.inkSoft,
    fontSize: 14,
    fontWeight: '800',
  },
  rowValue: {
    color: COLORS.violet,
    fontSize: 14,
    fontWeight: '900',
  },
  assistantCard: {
    alignItems: 'center',
    backgroundColor: COLORS.warning,
    borderColor: '#E8B870',
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 10,
    marginTop: 14,
    padding: 14,
  },
  assistantText: {
    color: '#8A5A20',
    flex: 1,
    fontSize: 13,
    fontWeight: '800',
    lineHeight: 19,
  },
});
