import { Ionicons } from '@expo/vector-icons';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

type IoniconName = keyof typeof Ionicons.glyphMap;

const COLORS = {
  violet: '#6D597A',
  violetDeep: '#5A4866',
  violetSoft: '#EDE8F0',
  blue: '#6E8894',
  blueSoft: '#EDF2F4',
  celadonDeep: '#7A9E6A',
  celadonSoft: '#EDF2EA',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
  warning: '#FFF5E8',
};

const profileStats = [
  { value: '184', label: 'cartes' },
  { value: '7j', label: 'serie' },
  { value: '82%', label: 'maitrise' },
];

const menuItems: { icon: IoniconName; label: string; value: string }[] = [
  { icon: 'school-outline', label: 'Filiere', value: 'Genie logiciel' },
  { icon: 'speedometer-outline', label: 'Niveau actuel', value: 'Intermediaire' },
  { icon: 'notifications-outline', label: 'Notifications', value: '4 alertes' },
  { icon: 'cloud-offline-outline', label: 'Mode hors-ligne', value: 'SQLite actif' },
  { icon: 'shield-checkmark-outline', label: 'Regles examen', value: 'Anti-sortie actif' },
];

export default function ProfileTab() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.kicker}>Compte et progression</Text>
            <Text style={styles.title}>Profil</Text>
          </View>
          <TouchableOpacity style={styles.iconButton} activeOpacity={0.75}>
            <Ionicons name="settings-outline" size={21} color={COLORS.ink} />
          </TouchableOpacity>
        </View>

        <View style={styles.identityCard}>
          <View style={styles.avatarWrap}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>M</Text>
            </View>
            <TouchableOpacity style={styles.editAvatar} activeOpacity={0.75}>
              <Ionicons name="pencil" size={12} color={COLORS.white} />
            </TouchableOpacity>
          </View>
          <Text style={styles.name}>Mireille Etienne</Text>
          <Text style={styles.meta}>B2 · Genie logiciel · Biochimie en priorite</Text>

          <View style={styles.statsRow}>
            {profileStats.map((stat) => (
              <View key={stat.label} style={styles.statBlock}>
                <Text style={styles.statValue}>{stat.value}</Text>
                <Text style={styles.statLabel}>{stat.label}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.assistantCard}>
          <View style={styles.assistantIcon}>
            <Ionicons name="sparkles" size={22} color={COLORS.white} />
          </View>
          <Text style={styles.assistantText}>
            Ton niveau diagnostic indique que les questions longues doivent revenir plus souvent.
          </Text>
        </View>

        <Text style={styles.sectionTitle}>Preferences Synapz</Text>
        {menuItems.map((item) => (
          <TouchableOpacity key={item.label} style={styles.menuRow} activeOpacity={0.75}>
            <View style={styles.menuIcon}>
              <Ionicons name={item.icon} size={20} color={COLORS.violet} />
            </View>
            <View style={styles.menuCopy}>
              <Text style={styles.menuLabel}>{item.label}</Text>
              <Text style={styles.menuValue}>{item.value}</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={COLORS.muted} />
          </TouchableOpacity>
        ))}

        <View style={styles.warningCard}>
          <Ionicons name="information-circle-outline" size={21} color="#8A5A20" />
          <Text style={styles.warningText}>
            Les sessions diagnostic et challenge sont securisees: une sortie de l'application annule
            la tentative.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.parchment,
  },
  content: {
    padding: 20,
    paddingBottom: 34,
  },
  header: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 18,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: 0,
    marginTop: 4,
  },
  iconButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    height: 44,
    justifyContent: 'center',
    width: 44,
  },
  identityCard: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 24,
    borderWidth: 1,
    padding: 20,
  },
  avatarWrap: {
    height: 92,
    width: 92,
  },
  avatar: {
    alignItems: 'center',
    backgroundColor: COLORS.violet,
    borderRadius: 32,
    height: 92,
    justifyContent: 'center',
    width: 92,
  },
  avatarText: {
    color: COLORS.white,
    fontSize: 36,
    fontWeight: '900',
  },
  editAvatar: {
    alignItems: 'center',
    backgroundColor: COLORS.celadonDeep,
    borderColor: COLORS.white,
    borderRadius: 999,
    borderWidth: 3,
    bottom: -2,
    height: 30,
    justifyContent: 'center',
    position: 'absolute',
    right: -2,
    width: 30,
  },
  name: {
    color: COLORS.ink,
    fontSize: 22,
    fontWeight: '900',
    marginTop: 14,
  },
  meta: {
    color: COLORS.muted,
    fontSize: 13,
    fontWeight: '700',
    marginTop: 4,
    textAlign: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    marginTop: 18,
    width: '100%',
  },
  statBlock: {
    alignItems: 'center',
    borderRightColor: '#EEECE3',
    borderRightWidth: 1,
    flex: 1,
  },
  statValue: {
    color: COLORS.ink,
    fontSize: 20,
    fontWeight: '900',
  },
  statLabel: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: '800',
    marginTop: 3,
  },
  assistantCard: {
    alignItems: 'center',
    backgroundColor: COLORS.violetDeep,
    borderRadius: 20,
    flexDirection: 'row',
    gap: 12,
    marginTop: 14,
    padding: 16,
  },
  assistantIcon: {
    alignItems: 'center',
    backgroundColor: COLORS.celadonDeep,
    borderRadius: 17,
    height: 42,
    justifyContent: 'center',
    width: 42,
  },
  assistantText: {
    color: COLORS.white,
    flex: 1,
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 20,
  },
  sectionTitle: {
    color: COLORS.ink,
    fontSize: 18,
    fontWeight: '900',
    marginBottom: 10,
    marginTop: 22,
  },
  menuRow: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 12,
    marginBottom: 10,
    padding: 13,
  },
  menuIcon: {
    alignItems: 'center',
    backgroundColor: COLORS.violetSoft,
    borderRadius: 15,
    height: 40,
    justifyContent: 'center',
    width: 40,
  },
  menuCopy: {
    flex: 1,
  },
  menuLabel: {
    color: COLORS.ink,
    fontSize: 14,
    fontWeight: '900',
  },
  menuValue: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: '700',
    marginTop: 2,
  },
  warningCard: {
    alignItems: 'center',
    backgroundColor: COLORS.warning,
    borderColor: '#E8B870',
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 10,
    marginTop: 8,
    padding: 14,
  },
  warningText: {
    color: '#8A5A20',
    flex: 1,
    fontSize: 13,
    fontWeight: '800',
    lineHeight: 19,
  },
});
