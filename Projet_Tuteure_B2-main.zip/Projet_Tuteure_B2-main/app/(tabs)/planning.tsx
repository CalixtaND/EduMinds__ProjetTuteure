import { PlanningContent } from '../planning';

export default function PlanningTab() {
  return <PlanningContent showBack={false} />;
}
