import { Ionicons } from '@expo/vector-icons';
import { Link, type Href } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

type IoniconName = keyof typeof Ionicons.glyphMap;

const COLORS = {
  violet: '#6D597A',
  violetDeep: '#5A4866',
  violetSoft: '#EDE8F0',
  blue: '#6E8894',
  blueSoft: '#EDF2F4',
  celadon: '#A2B997',
  celadonDeep: '#7A9E6A',
  celadonSoft: '#EDF2EA',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
  warning: '#FFF5E8',
};

const answers: { label: string; icon: IoniconName; color: string }[] = [
  { label: 'A revoir demain', icon: 'refresh-outline', color: '#8A3A3A' },
  { label: 'Difficile', icon: 'alert-circle-outline', color: '#8A5A20' },
  { label: 'Bien', icon: 'checkmark-circle-outline', color: COLORS.blue },
  { label: 'Parfait', icon: 'sparkles-outline', color: COLORS.celadonDeep },
];

const challengePlayers = [
  { name: 'Mireille', score: 840 },
  { name: 'Laure', score: 790 },
  { name: 'Kevin', score: 650 },
];

export default function ReviewScreen() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.kicker}>Session Leitner</Text>
            <Text style={styles.title}>Reviser</Text>
          </View>
          <View style={styles.timerPill}>
            <Ionicons name="time-outline" size={16} color={COLORS.violet} />
            <Text style={styles.timerText}>08:42</Text>
          </View>
        </View>

        <View style={styles.flashcard}>
          <View style={styles.flashTop}>
            <Text style={styles.flashSubject}>Biochimie</Text>
            <Text style={styles.flashLevel}>Niveau 3</Text>
          </View>
          <Text style={styles.question}>Quel est le role de l'ATP dans la contraction musculaire ?</Text>
          <View style={styles.answerBox}>
            <Text style={styles.answerTitle}>Reponse attendue</Text>
            <Text style={styles.answerText}>
              L'ATP fournit l'energie necessaire au detachage des ponts actine-myosine et au
              rearmement de la tete de myosine.
            </Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Auto-evaluation</Text>
        <View style={styles.answerGrid}>
          {answers.map((answer) => (
            <TouchableOpacity key={answer.label} style={styles.answerButton} activeOpacity={0.75}>
              <Ionicons name={answer.icon} size={20} color={answer.color} />
              <Text style={[styles.answerLabel, { color: answer.color }]}>{answer.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Link href={'/session-results' as Href} asChild>
          <TouchableOpacity style={styles.resultButton} activeOpacity={0.85}>
            <Ionicons name="stats-chart" size={17} color={COLORS.white} />
            <Text style={styles.resultButtonText}>Terminer et voir les resultats</Text>
          </TouchableOpacity>
        </Link>

        <Link href={'/import-course' as Href} asChild>
          <TouchableOpacity style={styles.importCard} activeOpacity={0.8}>
            <View style={styles.importIcon}>
              <Ionicons name="cloud-upload-outline" size={24} color={COLORS.white} />
            </View>
            <View style={styles.importCopy}>
              <Text style={styles.importTitle}>Importer un cours</Text>
              <Text style={styles.importText}>Photo ou PDF, puis generation IA des flashcards.</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.violet} />
          </TouchableOpacity>
        </Link>

        <Link href={'/diagnostic' as Href} asChild>
          <TouchableOpacity style={styles.diagnosticCard} activeOpacity={0.8}>
            <View style={styles.diagnosticHeader}>
              <Text style={styles.diagnosticTitle}>Evaluation diagnostic</Text>
              <Text style={styles.diagnosticBadge}>Verrouillee</Text>
            </View>
            <Text style={styles.diagnosticText}>
              Si l'etudiant sort de l'application, la tentative est annulee pour garder un resultat
              fiable.
            </Text>
          </TouchableOpacity>
        </Link>

        <Link href={'/challenge' as Href} asChild>
          <TouchableOpacity style={styles.challengeCard} activeOpacity={0.85}>
          <View style={styles.challengeHeader}>
            <View>
              <Text style={styles.challengeTitle}>Challenge live</Text>
              <Text style={styles.challengeSubtitle}>Code salle</Text>
            </View>
            <Text style={styles.challengeCode}>SYN-4F7K</Text>
          </View>

          {challengePlayers.map((player, index) => (
            <View key={player.name} style={styles.playerRow}>
              <View style={styles.rank}>
                <Text style={styles.rankText}>{index + 1}</Text>
              </View>
              <Text style={styles.playerName}>{player.name}</Text>
              <Text style={styles.playerScore}>{player.score} pts</Text>
            </View>
          ))}

          <View style={styles.challengeButton}>
            <Ionicons name="play" size={16} color={COLORS.white} />
            <Text style={styles.challengeButtonText}>Lancer 5 questions</Text>
          </View>
          </TouchableOpacity>
        </Link>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.parchment,
  },
  content: {
    padding: 20,
    paddingBottom: 34,
  },
  header: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 18,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 32,
    fontWeight: '800',
    letterSpacing: 0,
    marginTop: 4,
  },
  timerPill: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 999,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  timerText: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
  },
  flashcard: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 24,
    borderWidth: 1,
    padding: 20,
  },
  flashTop: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  flashSubject: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    textTransform: 'uppercase',
  },
  flashLevel: {
    backgroundColor: COLORS.violetSoft,
    borderRadius: 999,
    color: COLORS.violet,
    fontSize: 12,
    fontWeight: '800',
    overflow: 'hidden',
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  question: {
    color: COLORS.ink,
    fontSize: 24,
    fontWeight: '800',
    lineHeight: 32,
  },
  answerBox: {
    backgroundColor: COLORS.celadonSoft,
    borderRadius: 18,
    marginTop: 22,
    padding: 16,
  },
  answerTitle: {
    color: COLORS.celadonDeep,
    fontSize: 12,
    fontWeight: '800',
    marginBottom: 6,
    textTransform: 'uppercase',
  },
  answerText: {
    color: COLORS.inkSoft,
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 21,
  },
  sectionTitle: {
    color: COLORS.ink,
    fontSize: 19,
    fontWeight: '800',
    marginBottom: 12,
    marginTop: 24,
  },
  answerGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  answerButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    width: '48%',
  },
  answerLabel: {
    flex: 1,
    fontSize: 13,
    fontWeight: '800',
  },
  resultButton: {
    alignItems: 'center',
    backgroundColor: COLORS.violet,
    borderRadius: 18,
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'center',
    marginTop: 12,
    paddingVertical: 15,
  },
  resultButtonText: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: '900',
  },
  importCard: {
    alignItems: 'center',
    backgroundColor: COLORS.blueSoft,
    borderColor: '#CAD7DD',
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 12,
    marginTop: 22,
    padding: 16,
  },
  importIcon: {
    alignItems: 'center',
    backgroundColor: COLORS.blue,
    borderRadius: 18,
    height: 46,
    justifyContent: 'center',
    width: 46,
  },
  importCopy: {
    flex: 1,
  },
  importTitle: {
    color: COLORS.ink,
    fontSize: 16,
    fontWeight: '800',
  },
  importText: {
    color: COLORS.inkSoft,
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
    marginTop: 3,
  },
  diagnosticCard: {
    backgroundColor: COLORS.warning,
    borderColor: '#E8B870',
    borderRadius: 20,
    borderWidth: 1,
    marginTop: 12,
    padding: 16,
  },
  diagnosticHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  diagnosticTitle: {
    color: COLORS.ink,
    fontSize: 16,
    fontWeight: '800',
  },
  diagnosticBadge: {
    backgroundColor: COLORS.white,
    borderRadius: 999,
    color: '#8A5A20',
    fontSize: 11,
    fontWeight: '800',
    overflow: 'hidden',
    paddingHorizontal: 9,
    paddingVertical: 5,
  },
  diagnosticText: {
    color: COLORS.inkSoft,
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 19,
  },
  challengeCard: {
    backgroundColor: COLORS.violetDeep,
    borderRadius: 22,
    marginTop: 12,
    padding: 16,
  },
  challengeHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  challengeTitle: {
    color: COLORS.white,
    fontSize: 18,
    fontWeight: '800',
  },
  challengeSubtitle: {
    color: COLORS.violetSoft,
    fontSize: 12,
    fontWeight: '700',
    marginTop: 2,
  },
  challengeCode: {
    color: COLORS.white,
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 1,
  },
  playerRow: {
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 14,
    flexDirection: 'row',
    gap: 10,
    marginBottom: 8,
    padding: 10,
  },
  rank: {
    alignItems: 'center',
    backgroundColor: COLORS.celadon,
    borderRadius: 999,
    height: 26,
    justifyContent: 'center',
    width: 26,
  },
  rankText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '900',
  },
  playerName: {
    color: COLORS.white,
    flex: 1,
    fontSize: 14,
    fontWeight: '800',
  },
  playerScore: {
    color: COLORS.violetSoft,
    fontSize: 13,
    fontWeight: '800',
  },
  challengeButton: {
    alignItems: 'center',
    backgroundColor: COLORS.celadonDeep,
    borderRadius: 16,
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'center',
    marginTop: 8,
    paddingVertical: 14,
  },
  challengeButtonText: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: '900',
  },
});
