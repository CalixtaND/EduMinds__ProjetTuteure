import { ImportCourseContent } from '../import-course';

export default function ImporterTab() {
  return <ImportCourseContent showBack={false} />;
}
