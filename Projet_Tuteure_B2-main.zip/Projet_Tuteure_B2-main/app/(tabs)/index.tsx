import { Ionicons } from '@expo/vector-icons';
import { Link, type Href } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const COLORS = {
  violet: '#6D597A',
  violetDeep: '#5A4866',
  violetSoft: '#EDE8F0',
  blue: '#6E8894',
  blueSoft: '#EDF2F4',
  celadon: '#A2B997',
  celadonDeep: '#7A9E6A',
  celadonSoft: '#EDF2EA',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
  warning: '#FFF5E8',
};

const heatmap = Array.from({ length: 42 }, (_, index) => {
  const pattern = [0, 1, 3, 2, 0, 4, 1, 2, 4, 3, 0, 1, 2, 4];
  return pattern[index % pattern.length];
});

const subjects = [
  { name: 'Biochimie', progress: 78, due: '12 cartes', color: COLORS.violet },
  { name: 'Algorithmique', progress: 61, due: '8 cartes', color: COLORS.blue },
  { name: 'Base de donnees', progress: 43, due: '15 cartes', color: COLORS.celadonDeep },
];

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.kicker}>Bonjour Mireille</Text>
            <Text style={styles.title}>Ton plan de revision</Text>
          </View>
          <Link href={'/notifications' as Href} asChild>
          <TouchableOpacity style={styles.iconButton} activeOpacity={0.75}>
            <Ionicons name="notifications-outline" size={21} color={COLORS.ink} />
          </TouchableOpacity>
          </Link>
        </View>

        <View style={styles.heroCard}>
          <View style={styles.avatar}>
            <Ionicons name="sparkles" size={24} color={COLORS.white} />
          </View>
          <View style={styles.heroCopy}>
            <Text style={styles.heroEyebrow}>Assistant Synapz</Text>
            <Text style={styles.heroText}>
              Tu as 20 minutes aujourd'hui. On commence par les cartes qui risquent de s'oublier.
            </Text>
          </View>
        </View>

        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>35</Text>
            <Text style={styles.statLabel}>cartes dues</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>7j</Text>
            <Text style={styles.statLabel}>serie active</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>82%</Text>
            <Text style={styles.statLabel}>maitrise</Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Memoire active</Text>
          <Text style={styles.sectionLink}>42 jours</Text>
        </View>

        <View style={styles.heatmapCard}>
          <View style={styles.heatmap}>
            {heatmap.map((level, index) => (
              <View
                key={`${index}-${level}`}
                style={[styles.heatCell, { backgroundColor: heatColor(level) }]}
              />
            ))}
          </View>
          <View style={styles.heatLegend}>
            <Text style={styles.legendText}>Moins</Text>
            {[0, 1, 2, 3, 4].map((level) => (
              <View key={level} style={[styles.legendCell, { backgroundColor: heatColor(level) }]} />
            ))}
            <Text style={styles.legendText}>Plus</Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Matieres</Text>
          <Text style={styles.sectionLink}>Voir tout</Text>
        </View>

        {subjects.map((subject) => (
          <Link key={subject.name} href={'/subject-detail' as Href} asChild>
          <TouchableOpacity style={styles.subjectCard} activeOpacity={0.8}>
            <View style={[styles.subjectIcon, { backgroundColor: `${subject.color}22` }]}>
              <Ionicons name="book-outline" size={20} color={subject.color} />
            </View>
            <View style={styles.subjectContent}>
              <View style={styles.subjectTop}>
                <Text style={styles.subjectName}>{subject.name}</Text>
                <Text style={styles.subjectDue}>{subject.due}</Text>
              </View>
              <View style={styles.progressTrack}>
                <View
                  style={[
                    styles.progressFill,
                    { width: `${subject.progress}%`, backgroundColor: subject.color },
                  ]}
                />
              </View>
            </View>
          </TouchableOpacity>
          </Link>
        ))}

        <Link href={'/planning' as Href} asChild>
          <TouchableOpacity style={styles.planningCard} activeOpacity={0.8}>
            <View style={styles.planningDate}>
              <Text style={styles.planningDay}>02</Text>
              <Text style={styles.planningMonth}>JUN</Text>
            </View>
            <View style={styles.planningCopy}>
              <Text style={styles.planningTitle}>Examen de Biochimie</Text>
              <Text style={styles.planningText}>
                Planning reajuste: 4 sessions courtes avant l'echeance.
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#8A5A20" />
          </TouchableOpacity>
        </Link>
      </ScrollView>
    </SafeAreaView>
  );
}

function heatColor(level: number) {
  return ['#F1EEE5', '#DCE8D5', '#BFD4B5', '#95B985', '#6F9A60'][level];
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.parchment,
  },
  content: {
    padding: 20,
    paddingBottom: 34,
  },
  header: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 18,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 30,
    fontWeight: '700',
    letterSpacing: 0,
    marginTop: 4,
  },
  iconButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    height: 44,
    justifyContent: 'center',
    width: 44,
  },
  heroCard: {
    alignItems: 'center',
    backgroundColor: COLORS.violet,
    borderRadius: 22,
    flexDirection: 'row',
    gap: 14,
    padding: 18,
  },
  avatar: {
    alignItems: 'center',
    backgroundColor: COLORS.celadonDeep,
    borderRadius: 22,
    height: 54,
    justifyContent: 'center',
    width: 54,
  },
  heroCopy: {
    flex: 1,
  },
  heroEyebrow: {
    color: COLORS.violetSoft,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 4,
    textTransform: 'uppercase',
  },
  heroText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '600',
    lineHeight: 21,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 14,
  },
  statCard: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flex: 1,
    padding: 14,
  },
  statNumber: {
    color: COLORS.ink,
    fontSize: 23,
    fontWeight: '800',
  },
  statLabel: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: '600',
    marginTop: 4,
  },
  sectionHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
    marginTop: 24,
  },
  sectionTitle: {
    color: COLORS.ink,
    fontSize: 20,
    fontWeight: '800',
  },
  sectionLink: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '700',
  },
  heatmapCard: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 20,
    borderWidth: 1,
    padding: 16,
  },
  heatmap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  heatCell: {
    borderRadius: 4,
    height: 16,
    width: '12.5%',
  },
  heatLegend: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 5,
    justifyContent: 'flex-end',
    marginTop: 12,
  },
  legendText: {
    color: COLORS.muted,
    fontSize: 11,
    fontWeight: '600',
  },
  legendCell: {
    borderRadius: 3,
    height: 10,
    width: 10,
  },
  subjectCard: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 12,
    marginBottom: 10,
    padding: 14,
  },
  subjectIcon: {
    alignItems: 'center',
    borderRadius: 16,
    height: 42,
    justifyContent: 'center',
    width: 42,
  },
  subjectContent: {
    flex: 1,
  },
  subjectTop: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  subjectName: {
    color: COLORS.ink,
    fontSize: 15,
    fontWeight: '800',
  },
  subjectDue: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: '700',
  },
  progressTrack: {
    backgroundColor: '#EFEEE8',
    borderRadius: 999,
    height: 7,
    overflow: 'hidden',
  },
  progressFill: {
    borderRadius: 999,
    height: '100%',
  },
  planningCard: {
    alignItems: 'center',
    backgroundColor: COLORS.warning,
    borderColor: '#E8B870',
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 14,
    marginTop: 10,
    padding: 16,
  },
  planningDate: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderRadius: 16,
    paddingHorizontal: 13,
    paddingVertical: 10,
  },
  planningDay: {
    color: '#8A5A20',
    fontSize: 22,
    fontWeight: '900',
  },
  planningMonth: {
    color: '#8A5A20',
    fontSize: 11,
    fontWeight: '800',
  },
  planningCopy: {
    flex: 1,
  },
  planningTitle: {
    color: COLORS.ink,
    fontSize: 15,
    fontWeight: '800',
  },
  planningText: {
    color: COLORS.inkSoft,
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 19,
    marginTop: 3,
  },
});
