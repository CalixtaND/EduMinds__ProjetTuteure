import { ChallengeContent } from '../challenge';

export default function ChallengeTab() {
  return <ChallengeContent showBack={false} />;
}
