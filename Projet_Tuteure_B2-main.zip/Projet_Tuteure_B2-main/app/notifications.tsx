import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const COLORS = {
  violet: '#6D597A',
  celadonDeep: '#7A9E6A',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
  warning: '#FFF5E8',
};

const notifications = [
  { icon: 'trophy-outline', title: 'Laure E. t invite a un challenge', time: 'Il y a 5 min' },
  { icon: 'calendar-outline', title: 'Examen Biochimie dans 6 jours', time: 'Aujourd hui' },
  { icon: 'refresh-outline', title: '12 cartes sont repassees en boite 1', time: 'Hier' },
  { icon: 'cloud-offline-outline', title: 'Pack hors-ligne synchronise', time: 'Hier' },
];

export default function NotificationsScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()} activeOpacity={0.75}>
          <Ionicons name="chevron-back" size={20} color={COLORS.ink} />
        </TouchableOpacity>
        <Text style={styles.kicker}>Alertes</Text>
        <Text style={styles.title}>Notifications</Text>

        <View style={styles.filters}>
          <Text style={[styles.filter, styles.filterActive]}>Toutes</Text>
          <Text style={styles.filter}>Revision</Text>
          <Text style={styles.filter}>Challenges</Text>
        </View>

        {notifications.map((notification) => (
          <View key={notification.title} style={styles.notificationRow}>
            <View style={styles.notificationIcon}>
              <Ionicons name={notification.icon as keyof typeof Ionicons.glyphMap} size={20} color={COLORS.violet} />
            </View>
            <View style={styles.notificationCopy}>
              <Text style={styles.notificationTitle}>{notification.title}</Text>
              <Text style={styles.notificationTime}>{notification.time}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.parchment },
  content: { padding: 20, paddingBottom: 34 },
  backButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 16,
    borderWidth: 1,
    height: 42,
    justifyContent: 'center',
    marginBottom: 18,
    width: 42,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 31,
    fontWeight: '900',
    letterSpacing: 0,
    marginTop: 4,
  },
  filters: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
    marginTop: 22,
    padding: 6,
  },
  filter: {
    borderRadius: 13,
    color: COLORS.muted,
    flex: 1,
    fontSize: 13,
    fontWeight: '900',
    overflow: 'hidden',
    paddingVertical: 9,
    textAlign: 'center',
  },
  filterActive: {
    backgroundColor: COLORS.violet,
    color: COLORS.white,
  },
  notificationRow: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 12,
    marginBottom: 10,
    padding: 14,
  },
  notificationIcon: {
    alignItems: 'center',
    backgroundColor: '#EDE8F0',
    borderRadius: 15,
    height: 42,
    justifyContent: 'center',
    width: 42,
  },
  notificationCopy: { flex: 1 },
  notificationTitle: {
    color: COLORS.ink,
    fontSize: 14,
    fontWeight: '900',
  },
  notificationTime: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: '700',
    marginTop: 3,
  },
});
