import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const COLORS = {
  violet: '#6D597A',
  blue: '#6E8894',
  celadonDeep: '#7A9E6A',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  muted: '#8B8B98',
  warning: '#FFF5E8',
};

const sessions = [
  { day: '28', month: 'MAI', title: 'Biochimie', detail: '20 min · 12 cartes dues', tag: 'Aujourd hui' },
  { day: '29', month: 'MAI', title: 'Algorithmique', detail: '25 min · arbres et graphes', tag: 'Leitner' },
  { day: '30', month: 'MAI', title: 'Base de donnees', detail: '15 min · normalisation', tag: 'Rattrapage' },
  { day: '02', month: 'JUN', title: 'Examen · Biochimie', detail: 'Derniere revision guidee', tag: 'Examen' },
];

export function PlanningContent({ showBack = true }: { showBack?: boolean }) {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {showBack ? (
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()} activeOpacity={0.75}>
            <Ionicons name="chevron-back" size={20} color={COLORS.ink} />
          </TouchableOpacity>
        ) : (
          <View style={styles.topSpacer} />
        )}

        <Text style={styles.kicker}>Planning adaptatif</Text>
        <Text style={styles.title}>Cette semaine</Text>
        <Text style={styles.subtitle}>
          Le programme se reajuste si tu rates une journee, sans perdre les cartes les plus fragiles.
        </Text>

        <View style={styles.alertCard}>
          <Ionicons name="sparkles-outline" size={22} color={COLORS.celadonDeep} />
          <Text style={styles.alertText}>
            Tu es dans les temps pour l'examen du 2 juin si tu maintiens 20 min par jour.
          </Text>
        </View>

        <View style={styles.tabs}>
          <Text style={[styles.tab, styles.tabActive]}>Revision</Text>
          <Text style={styles.tab}>Examens</Text>
          <Text style={styles.tab}>Retards</Text>
        </View>

        {sessions.map((session) => (
          <View
            key={`${session.day}-${session.title}`}
            style={[styles.sessionCard, session.tag === 'Examen' && styles.examCard]}>
            <View style={styles.dateBox}>
              <Text style={styles.dateDay}>{session.day}</Text>
              <Text style={styles.dateMonth}>{session.month}</Text>
            </View>
            <View style={styles.sessionCopy}>
              <Text style={styles.sessionTitle}>{session.title}</Text>
              <Text style={styles.sessionDetail}>{session.detail}</Text>
            </View>
            <Text style={[styles.tag, session.tag === 'Examen' && styles.examTag]}>{session.tag}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

export default function PlanningScreen() {
  return <PlanningContent />;
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.parchment },
  content: { padding: 20, paddingBottom: 34 },
  backButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 16,
    borderWidth: 1,
    height: 42,
    justifyContent: 'center',
    marginBottom: 18,
    width: 42,
  },
  topSpacer: {
    height: 8,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 31,
    fontWeight: '900',
    letterSpacing: 0,
    marginTop: 4,
  },
  subtitle: {
    color: COLORS.inkSoft,
    fontSize: 15,
    fontWeight: '600',
    lineHeight: 22,
    marginTop: 10,
  },
  alertCard: {
    alignItems: 'center',
    backgroundColor: '#EDF2EA',
    borderColor: '#D3E0CC',
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 12,
    marginTop: 22,
    padding: 16,
  },
  alertText: {
    color: COLORS.inkSoft,
    flex: 1,
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 20,
  },
  tabs: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 8,
    marginTop: 18,
    padding: 6,
  },
  tab: {
    borderRadius: 13,
    color: COLORS.muted,
    flex: 1,
    fontSize: 13,
    fontWeight: '900',
    overflow: 'hidden',
    paddingVertical: 9,
    textAlign: 'center',
  },
  tabActive: {
    backgroundColor: COLORS.violet,
    color: COLORS.white,
  },
  sessionCard: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 12,
    marginTop: 12,
    padding: 14,
  },
  examCard: {
    backgroundColor: COLORS.warning,
    borderColor: '#E8B870',
  },
  dateBox: {
    alignItems: 'center',
    backgroundColor: COLORS.parchment,
    borderRadius: 15,
    paddingHorizontal: 12,
    paddingVertical: 9,
  },
  dateDay: {
    color: COLORS.ink,
    fontSize: 20,
    fontWeight: '900',
  },
  dateMonth: {
    color: COLORS.muted,
    fontSize: 10,
    fontWeight: '900',
  },
  sessionCopy: { flex: 1 },
  sessionTitle: {
    color: COLORS.ink,
    fontSize: 15,
    fontWeight: '900',
  },
  sessionDetail: {
    color: COLORS.inkSoft,
    fontSize: 12,
    fontWeight: '700',
    marginTop: 3,
  },
  tag: {
    backgroundColor: '#EDF2F4',
    borderRadius: 999,
    color: COLORS.blue,
    fontSize: 11,
    fontWeight: '900',
    overflow: 'hidden',
    paddingHorizontal: 9,
    paddingVertical: 5,
  },
  examTag: {
    backgroundColor: COLORS.white,
    color: '#8A5A20',
  },
});
