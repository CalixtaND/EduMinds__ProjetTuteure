import { Ionicons } from '@expo/vector-icons';
import { Link, type Href, useRouter } from 'expo-router';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const COLORS = {
  violet: '#6D597A',
  violetDeep: '#5A4866',
  violetSoft: '#EDE8F0',
  blue: '#6E8894',
  celadonDeep: '#7A9E6A',
  parchment: '#FAF8F3',
  ink: '#2B2D42',
  inkSoft: '#4A4D63',
  sand: '#E2DEC3',
  white: '#FFFFFF',
  warning: '#FFF5E8',
};

const players = [
  { name: 'Mireille', status: 'Pret', color: COLORS.violet },
  { name: 'Laure', status: 'Pret', color: COLORS.celadonDeep },
  { name: 'Kevin', status: 'Connexion', color: COLORS.blue },
];

export function ChallengeContent({ showBack = true }: { showBack?: boolean }) {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {showBack ? (
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()} activeOpacity={0.75}>
            <Ionicons name="chevron-back" size={20} color={COLORS.ink} />
          </TouchableOpacity>
        ) : (
          <View style={styles.topSpacer} />
        )}

        <Text style={styles.kicker}>Mode competition</Text>
        <Text style={styles.title}>Challenge</Text>
        <Text style={styles.subtitle}>
          Cree une salle, partage le code et lance une serie de questions chronometrees.
        </Text>

        <View style={styles.codeCard}>
          <Text style={styles.codeLabel}>Code de ta salle</Text>
          <Text style={styles.code}>SYN-4F7K</Text>
          <View style={styles.actions}>
            <TouchableOpacity style={styles.actionButton} activeOpacity={0.8}>
              <Ionicons name="copy-outline" size={16} color={COLORS.violet} />
              <Text style={styles.actionText}>Copier</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton} activeOpacity={0.8}>
              <Ionicons name="share-social-outline" size={16} color={COLORS.violet} />
              <Text style={styles.actionText}>Partager</Text>
            </TouchableOpacity>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Joueurs</Text>
        {players.map((player) => (
          <View key={player.name} style={styles.playerRow}>
            <View style={[styles.avatar, { backgroundColor: player.color }]}>
              <Text style={styles.avatarText}>{player.name[0]}</Text>
            </View>
            <Text style={styles.playerName}>{player.name}</Text>
            <Text style={styles.playerStatus}>{player.status}</Text>
          </View>
        ))}

        <View style={styles.warningCard}>
          <Ionicons name="warning-outline" size={21} color="#8A5A20" />
          <Text style={styles.warningText}>
            Si un joueur sort de l'application pendant le challenge, son round est annule.
          </Text>
        </View>

        <Link href={'/challenge-live' as Href} asChild>
          <TouchableOpacity style={styles.primaryButton} activeOpacity={0.85}>
            <Ionicons name="play" size={16} color={COLORS.white} />
            <Text style={styles.primaryButtonText}>Lancer le challenge · 5 questions</Text>
          </TouchableOpacity>
        </Link>
      </ScrollView>
    </SafeAreaView>
  );
}

export default function ChallengeScreen() {
  return <ChallengeContent />;
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.parchment },
  content: { padding: 20, paddingBottom: 34 },
  backButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 16,
    borderWidth: 1,
    height: 42,
    justifyContent: 'center',
    marginBottom: 18,
    width: 42,
  },
  topSpacer: {
    height: 8,
  },
  kicker: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    color: COLORS.ink,
    fontSize: 31,
    fontWeight: '900',
    letterSpacing: 0,
    marginTop: 4,
  },
  subtitle: {
    color: COLORS.inkSoft,
    fontSize: 15,
    fontWeight: '600',
    lineHeight: 22,
    marginTop: 10,
  },
  codeCard: {
    alignItems: 'center',
    backgroundColor: COLORS.violetDeep,
    borderRadius: 24,
    marginTop: 24,
    padding: 22,
  },
  codeLabel: {
    color: COLORS.violetSoft,
    fontSize: 12,
    fontWeight: '900',
    textTransform: 'uppercase',
  },
  code: {
    color: COLORS.white,
    fontSize: 34,
    fontWeight: '900',
    letterSpacing: 2,
    marginTop: 8,
  },
  actions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 18,
  },
  actionButton: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderRadius: 999,
    flexDirection: 'row',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  actionText: {
    color: COLORS.violet,
    fontSize: 13,
    fontWeight: '900',
  },
  sectionTitle: {
    color: COLORS.ink,
    fontSize: 18,
    fontWeight: '900',
    marginBottom: 10,
    marginTop: 22,
  },
  playerRow: {
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderColor: COLORS.sand,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 12,
    marginBottom: 10,
    padding: 13,
  },
  avatar: {
    alignItems: 'center',
    borderRadius: 999,
    height: 38,
    justifyContent: 'center',
    width: 38,
  },
  avatarText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '900',
  },
  playerName: {
    color: COLORS.ink,
    flex: 1,
    fontSize: 15,
    fontWeight: '900',
  },
  playerStatus: {
    color: COLORS.celadonDeep,
    fontSize: 12,
    fontWeight: '900',
  },
  warningCard: {
    alignItems: 'center',
    backgroundColor: COLORS.warning,
    borderColor: '#E8B870',
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    gap: 10,
    marginTop: 8,
    padding: 14,
  },
  warningText: {
    color: '#8A5A20',
    flex: 1,
    fontSize: 13,
    fontWeight: '800',
    lineHeight: 19,
  },
  primaryButton: {
    alignItems: 'center',
    backgroundColor: COLORS.celadonDeep,
    borderRadius: 18,
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'center',
    marginTop: 18,
    paddingVertical: 16,
  },
  primaryButtonText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '900',
  },
});
